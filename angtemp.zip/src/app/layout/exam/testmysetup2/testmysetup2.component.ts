import { Component, OnInit } from '@angular/core';
import { Route, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-testmysetup2',
  templateUrl: './testmysetup2.component.html',
  styleUrls: ['./testmysetup2.component.css']
})
export class Testmysetup2Component implements OnInit {

  constructor(private router: ActivatedRoute) { }

  ngOnInit() {
  }

}
