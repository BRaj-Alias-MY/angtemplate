import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import {PaymentsService} from '../../payments/services/payments.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';



import { PayPalConfig, PayPalEnvironment, PayPalIntegrationType } from 'ngx-paypal';

@Component({
  selector: 'app-paypal',
  templateUrl: './paypal.component.html',
  styleUrls: ['./paypal.component.css']
})
export class PaypalComponent implements OnInit {

  public payPalConfig?: PayPalConfig;
  amt : any;
  amount;
  resp:any;
  constructor(private route: ActivatedRoute,private fb: FormBuilder,private api : PaymentsService) { }

  ngOnInit() {
    this.amt = this.route.snapshot.queryParamMap.get('id');
    this.api.get_amount(this.amt).subscribe((res) => {
      this.resp = res.data;
      if (res.status) {
        this.amount = Math.round(res.data.total);
        this.initConfig();
      } else {
        //alert('Fail');
        //Swal('Oops...', 'Something went wrong!', 'error');
      }
    });

    this.initConfig();
    
  }

  private initConfig(): void {
    this.payPalConfig = new PayPalConfig(PayPalIntegrationType.ClientSideREST, PayPalEnvironment.Sandbox, {
      commit: true,
      client: {
        sandbox: 'AWg2gnNetniWFX9MdxZD9-eXMOqmKU9bebPW063tzKVpaHOl1PQHxXt7ttkeC8v-FdnQRrwevllx844b'
      },
      button: {
        label: 'paypal',
      },
      onPaymentComplete: (data, actions) => {
        console.log('OnPaymentComplete');
        console.log(data);
        //let Indata = {'main': data, 'id':this.amt };
        let Indata = {"paymentMode":"paypal","price":this.amount,"pgResponse":data,"status":"sucess"};
       // console.log('==============');
       // console.log(actions);
       this.api.save_info(Indata,this.amt).subscribe((res) => {
        if (res.status) {
         // console.log(res); 
         Swal.fire('Success..', 'Your Payment is Sucessfully Processed', 'success');
         //this.route.navigate(['/main/payment'], { queryParams: { id: res.data.id }});
        // this.route.navigateByUrl('/login');


        } else {
          // alert('Fail');
          Swal.fire('Oops...', 'Something went wrong!', 'error');

        }
      });
        
      },
      onCancel: (data, actions) => {
        console.log('OnCancel');
        console.log(data);
        console.log('==============');
        console.log(actions);
        Swal.fire('Oops...', 'Something went wrong!', 'error');
        let Indata = {"paymentMode":"paypal","price":this.amount,"pgResponse":data,"status":"cancel"};
        this.api.save_info(Indata,this.amt).subscribe((res) => {
          if (res.status) {
           // console.log(res);
          // Swal.fire('Success..', 'Your Payment is Sucessfully Processed', 'success');
  
          } 
        });

      },
      onError: (err) => {
        console.log('OnError');
        Swal.fire('Oops...', 'Something went wrong!', 'error');

        let Indata = {"paymentMode":"paypal","price":this.amount,"pgResponse":err,"status":"failed"};
        this.api.save_info(Indata,this.amt).subscribe((res) => {
          if (res.status) {
           // console.log(res);
          // Swal.fire('Success..', 'Your Payment is Sucessfully Processed', 'success');
  
          } 
        });
      },
      experience: {
        noShipping: true,
        brandName: 'Interview Buddy'
      },
      transactions: [{
        amount: {
          currency: 'USD',
          total: this.amount
        }
      }]
    });
  }

}
