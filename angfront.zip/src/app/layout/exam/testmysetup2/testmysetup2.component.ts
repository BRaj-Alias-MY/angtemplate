import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testmysetup2',
  templateUrl: './testmysetup2.component.html',
  styleUrls: ['./testmysetup2.component.css']
})
export class Testmysetup2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
