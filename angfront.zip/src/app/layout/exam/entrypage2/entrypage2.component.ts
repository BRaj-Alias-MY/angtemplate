import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrypage2',
  templateUrl: './entrypage2.component.html',
  styleUrls: ['./entrypage2.component.css']
})
export class Entrypage2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
