import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import { ValidationService } from '../../../services/validation.service';
import {ExpertService} from '../services/expert.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';

@Component({
  selector: 'app-assignexpert',
  templateUrl: './assignexpert.component.html',
  styleUrls: ['./assignexpert.component.css']
})
export class AssignexpertComponent implements OnInit {
  experts;
  interviews;
  update;
	items;
	lenght;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
  IsForUpdate: boolean = false;
  btn_name;
  grid_tab;
  //main_tab;
  public main_tab: any[] = [];

  selectedRow: any;
  selectedAll: boolean = false;
  selectedDevice;
  private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  constructor(private fb: FormBuilder, private route: Router, private api: ExpertService) {
    this.gridOptions = <GridOptions>{
			paginationNumberFormatter: function(params) {
				return '[' + params.value.toLocaleString() + ']';
			}
		};
		this.columnDefs = [
      { headerName: 'E-mail', field: 'email' },
      { headerName: 'Interview ID', field: 'interviewId' },
			{
				headerName: 'Action',
				cellRenderer: 'childMessageRenderer',
				colId: 'params',
				value: 'id'
			}
		];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
   }

  ngOnInit() {
    this.btn_name = 'Save';
    this.api.get_interviewids().subscribe(res=> this.interviews = res.data);
    this.api.get_experts().subscribe(res=> this.experts = res.data);
    this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};
    this.grid();
    this.grid_tab = [];
    this.main_tab = [];
    this.selectedRow = [];


  }
  onEditClick(id) {
		console.log(id);
	} 

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
	}

  interviewassignForm = this.fb.group({
		id:[],
    interviewUserId: [''],
    expertId: ['']
    });

    onSubmit(){
      console.log(this.interviewassignForm.value);
     this.api.save_interviewassign(this.interviewassignForm.value).subscribe((res) => {
				if (res.status) {
					this.interviewassignForm.patchValue({ interviewid: '' });
					// this.grid();
          Swal.fire('Interview Assignment Completed', 'success');
					// this.clear_fields();
				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Something went wrong!', 'error');
				}
			}); 
    }

    grid(){
      this.api.get_interviewids().subscribe((data) => {
         this.grid_tab = data.data;
         console.log(this.grid_tab);
       
      });

    }

    onChange($event) {
   // alert(this.selectedDevice);  
   console.log(this.grid_tab.length);
    for (let i = 0; i < this.grid_tab.length; i++) {
      // console.log(this.paymentmanagementForm.value.interviewtype);
     // this.selectedDevice == this.grid_tab[i].id;
      if (this.selectedDevice == this.grid_tab[i].id){
          this.main_tab = this.grid_tab[i];
         // dataArr.push(csvRecord);
         // this.main_tab.push(this.grid_tab[i]);
          console.log(this.main_tab);
      }
     // console.log(value);
   }   
     }
   /* selectAll(index){
      if (typeof (index) == 'undefined') {
        this.selectedAll = !this.selectedAll;
        this.selectedRow = [];
       } else {
        this.selectedRow.push(index);
        console.log(this.selectedRow);
       }
    } */

}
export class main_tab {
  public domainName: any;
	public subDomainName: any;
	public experiance: any;
	public email: any;
	public interviewId: any;
}
