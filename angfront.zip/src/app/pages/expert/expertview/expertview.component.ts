import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ExpertService } from '../services/expert.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';

@Component({
  selector: 'app-expertview',
  templateUrl: './expertview.component.html',
  styleUrls: ['./expertview.component.css']
})
export class ExpertviewComponent implements OnInit {
  view_item = [];

  access;
  grid_tab;
  constructor(
    private fb: FormBuilder,
    private route: Router,
    private api: ExpertService
  ) {}

  get_item_data_with_id(item_id) {
    for (let i = 0; i < this.grid_tab.length; i++) {
      if (this.grid_tab[i].id == item_id) {
        return this.grid_tab[i];
      }
    }
  }
  ngOnInit() {
    this.access = {
      addAccess: 0,
      editAccess: 0,
      deleteAccess: 0,
      gridAccess: 0
    };
    this.grid_tab = [];
    this.grid();
  }
  gotoReview(id) {
    localStorage.setItem('reviewId', id);
    this.route.navigate(['/main/expertreview']);
  }

  grid() {
    // console.log(this.current_page);
    this.api.get_expertlist().subscribe(data => {
      this.grid_tab = data.data;
      console.log(this.grid_tab);
    });
  }
}
