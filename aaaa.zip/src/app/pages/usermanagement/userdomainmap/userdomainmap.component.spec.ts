import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserdomainmapComponent } from './userdomainmap.component';

describe('UserdomainmapComponent', () => {
  let component: UserdomainmapComponent;
  let fixture: ComponentFixture<UserdomainmapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserdomainmapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserdomainmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
