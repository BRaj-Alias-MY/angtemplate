import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpertviewComponent } from './expertview.component';

describe('ExpertviewComponent', () => {
  let component: ExpertviewComponent;
  let fixture: ComponentFixture<ExpertviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpertviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpertviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
