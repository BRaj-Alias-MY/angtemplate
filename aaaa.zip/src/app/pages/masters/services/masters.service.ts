import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../services/api.service';

@Injectable({
	providedIn: 'root'
})
export class MastersService {
	constructor(private main_api: ApiService, private http: HttpClient) {}

	add_organization(data) {
		return this.http.post<any>(this.main_api.get_base() + 'organization', data);
	}
	add_reviewskills(data) {
		return this.http.post<any>(this.main_api.get_base() + 'reportparam', data);
	}
	get_reviewskills_data() {
		return this.http.get<any>(this.main_api.get_base() + 'reportparam/');
	}
	expert_level_update(data){
		return this.http.post<any>(this.main_api.get_base()+"exp-level/"+data.id, data);
	 }
	reviewskillsForm_update(data) {
		return this.http.post<any>(this.main_api.get_base() + 'reportparam/' + data.id, data);
	}

	add_domain(data) {
		return this.http.post<any>(this.main_api.get_base() + 'domain', data);
	}

	update_domain(data) {
		return this.http.post<any>(this.main_api.get_base() + 'domain/'+ data.id, data);
	}
	add_expertlevel(data) {
		return this.http.post<any>(this.main_api.get_base()+"exp-level",data);
	  }
 get_expert_data(){
		return this.http.get<any>(this.main_api.get_base()+"exp-level/");
	   }
	get_domain_data() {
		return this.http.get<any>(this.main_api.get_base() + 'domain/');
	}
	get_update_organisation_data(id) {
		return this.http.get<any>(this.main_api.get_base() + 'organization/' + id);
	}
	add_users(data) {
		return this.http.post<any>(this.main_api.get_base() + 'user/bulk-user', data);
	}
	save_questions(data) {
		return this.http.post<any>(this.main_api.get_base() + 'questions/bulk-upload', data);
	}
	valid_questions(data) {
		return this.http.post<any>(this.main_api.get_base() + 'questions/validate', data);
	}
	valid_users(data) {
		return this.http.post<any>(this.main_api.get_base() + 'user/bulk-user-validate', data);
	}
	get_organization_data() {
		return this.http.get<any>(this.main_api.get_base()+"organization/");
	  }
	add_organization_update(data) {
		return this.http.post<any>(this.main_api.get_base() + 'organization/update', data);
	}

	add_usergroup(data) {
		return this.http.post<any>(this.main_api.get_base()+"usergroup",data);
		}
	update_usergroup(data){
			return this.http.post<any>(this.main_api.get_base() + 'usergroup/'+ data.id, data);
    }
	  get_usergroup_data(){
		return this.http.get<any>(this.main_api.get_base()+"usergroup/");
	  }
	 add_question(data) {
		return this.http.post<any>(this.main_api.get_base()+"questions",data);
	  }
	  get_questions_data(){
		return this.http.get<any>(this.main_api.get_base()+"questions/");
	  }
	  question_update(data){
		return this.http.post<any>(this.main_api.get_base() +  'questions/' + data.id, data);
     }
		 add_interviewtype(data) {
			return this.http.post<any>(this.main_api.get_base()+"interviewtype",data);
			}
			get_interviewtype(){
				return this.http.get<any>(this.main_api.get_base()+"interviewtype/");
				}
				interviewtype_update(data){
					return this.http.post<any>(this.main_api.get_base() +  'interviewtype/' + data.id, data);
					 }		
    valid_question_temp(data) {
		return this.http.post<any>(this.main_api.get_base() + 'questiontemp/validate', data);
	}
	save_question_temp(data) {
		return this.http.post<any>(this.main_api.get_base() + 'questiontemp/bulk-upload', data);
	}
	get_question_data(){
		return this.http.get<any>(this.main_api.get_base()+"questiontemp/");
	}
	add_questions(data) {
		return this.http.post<any>(this.main_api.get_base()+"questiontemp",data);
		}
		get_qc_data(){
			return this.http.get<any>(this.main_api.get_base()+"questiontemp/qc");
		}
	quality_check(data){
		return this.http.post<any>(this.main_api.get_base() +  "questiontemp/qc" ,data);
	}


					 					 
get_domains(){
	return this.http.get<any>(this.main_api.get_base()+'domain/list');
	}
	get_subdomain(id){
		return this.http.get<any>(this.main_api.get_base()+'domain/list/' + id);
	 }
					
	get_explevels(){
	return this.http.get<any>(this.main_api.get_base()+"exp-level/list");
	}				 

}
