import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-exam2',
  templateUrl: './exam2.component.html',
  styleUrls: ['./exam2.component.css']
})
export class Exam2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
